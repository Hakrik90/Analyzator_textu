#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/m18_bag_help.py
"""
Příkazy a záznamy odpovědí zadávané ve výpisech kapitoly:
18  Batoh a nápověda.
"""



#Výpis 18.1: Upravená definice třídy Item v modulu world v balíčku game_v1h
############################################################################



#Výpis 18.2: Definice metody try_add() ve třídě Bag v modulu world v balíčku game_v1h
############################################################################



#Výpis 18.3: Definice metody execute() ve třídě _Tak v modulu actions v balíčku game_v1h
############################################################################



#Výpis 18.4: Definice třídy _Help v modulu actions v balíčku game_v1h
############################################################################



#Výpis 18.5: Upravená definice metody execute_command()v modulu game v balíčku game_v1h
############################################################################



############################################################################
##### KONEC #####
