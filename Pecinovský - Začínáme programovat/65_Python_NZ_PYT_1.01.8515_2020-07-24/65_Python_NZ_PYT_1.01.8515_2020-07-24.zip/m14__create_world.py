#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/m14__create_world.py
"""
Příkazy a záznamy odpovědí zadávané ve výpisech kapitoly:
14  Vytváříme svět hry
"""



#Výpis 14.1: Definice třídy ANamed v modulu world v balíčku game_v1d
############################################################################

# Definice je v souboru ./game/game_v1d/world.py



#Výpis 14.2: Upravená definice třídy Item v modulu world v balíčku game_v1d
############################################################################

# Definice je v souboru ./game/game_v1d/world.py



#Výpis 14.3: Upravená definice třídy Place v modulu world v balíčku game_v1d
############################################################################

# Definice je v souboru ./game/game_v1d/world.py



#Výpis 14.4: Definice atributu _NAME_2_PLACE v modulu world v balíčku game_v1d
############################################################################

# Definice je v souboru ./game/game_v1d/world.py



#Výpis 14.5: Konec zprávy o průběhu testu aplikace v balíčku game_v1d
############################################################################
# =============================== RESTART: Shell ==============================
import game.game_v1c.scenarios
# ##### game - Společný rodičovský balíček balíčků jednotlivých verzí her
# ##### game.game_v1c - Balíček s verzí hry po definici startu hry na konci 12. kapitoly
# ===== Modul game.game_v1c.scenarios ===== START
# ===== Modul game.game_v1c.game ===== START
# ===== Modul game.game_v1c.actions ===== START
# ===== Modul game.game_v1c.world ===== START
# ===== Modul game.game_v1c.world ===== STOP
# ===== Modul game.game_v1c.actions ===== STOP
# ===== Modul game.game_v1c.game ===== STOP
# ===== Modul game.game_v1c.scenarios ===== STOP
# Spuštěna metoda game.game_v1c.game.game_v1c.scenarios.test_scenario
# 0.
# ------------------------------
#
# ------------------------------
# Vítejte!
# Toto je příběh o Červené Karkulce, babičce a vlkovi.
# Svými příkazy řídíte Karkulku, aby donesla věci babičce.
# Nebudete-li si vědět rady, zadejte znak ?.
# ============================================================
#
# 1.
# ------------------------------
# Vezmi víno
# ------------------------------
# Tento příkaz neznám: vezmi
# ============================================================
#
# V 1. kroku neodpovídá: odpověď hry
#    Očekáváno: Karkulka dala do košíku objekt: Víno
#    Obdrženo:  Tento příkaz neznám: vezmi
# Stisk klávesy Enter aplikaci ukončí
# >>>



############################################################################
##### KONEC #####
