print('''
    Toto je první spuštěný skript v Pythonu.
    Až si text přečtete, stiskněte Enter.
    ''')

input('Stiskněte Enter')
