#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/m12__start_game.py
"""
Příkazy a záznamy odpovědí zadávané ve výpisech kapitoly:
12  Definujeme start hry
"""



#Výpis 12.1: Definice metody execute_command() v modulu game v balíčku game_v1c
############################################################################

# Definice je v souboru ./game/game_v1c/game.py



#Výpis 12.2: Definice metody execute_command() v modulu actions v balíčku game_v1c
############################################################################

# Definice je v souboru ./game/game_v1c/actions.py



#Výpis 12.3: Definice metody _execute_standard_command() v modulu actions
############################################################################

# Definice je v souboru ./game/game_v1c/actions.py



#Výpis 12.4: Prozatímní definice metody _initialize() v modulu actions
############################################################################

# Definice je v souboru ./game/game_v1c/actions.py



#Výpis 12.5: Definice funkce _execute_standard_command() v modulu actions
############################################################################

# Definice je v souboru ./game/game_v1c/actions.py



#Výpis 12.6: Import modulu scenarios v balíčku game_v1c
############################################################################
# ============================ RESTART: Shell ============================
import game.game_v1c.scenarios
# ##### game - Společný rodičovský balíček balíčků jednotlivých verzí her
# ##### game.game_v1c - Balíček s verzí hry po definici startu hry na konci 12. kapitoly
# ===== Modul game.game_v1c.scenarios ===== START
# ===== Modul game.game_v1c.game ===== START
# ===== Modul game.game_v1c.actions ===== START
# ===== Modul game.game_v1c.world ===== START
# ===== Modul game.game_v1c.world ===== STOP
# ===== Modul game.game_v1c.actions ===== STOP
# ===== Modul game.game_v1c.game ===== STOP
# ===== Modul game.game_v1c.scenarios ===== STOP
# Spuštěna metoda game.game_v1c.game.game_v1c.scenarios.test_scenario
# 0.
# ------------------------------
#
# ------------------------------
# Vítejte!
# Toto je příběh o Červené Karkulce, babičce a vlkovi.
# Svými příkazy řídíte Karkulku, aby donesla věci babičce.
# Nebudete-li si vědět rady, zadejte znak ?.
# ============================================================
#
# Traceback (most recent call last):
#   File "<pyshell#2>", line 1, in <module>
#     import game.game_v1c.scenarios
#   File "Q:\65_PGM\65_PYT\game\game_v1c\scenarios.py", line 206, in <module>
#     test_scenario(HAPPY_SCENARIO)
#   File "Q:\65_PGM\65_PYT\game\game_v1c\scenarios.py", line 180, in test_scenario
#     if  step.place != current_place.name:
# AttributeError: 'NoneType' object has no attribute 'name'
# >>>



############################################################################
##### KONEC #####
