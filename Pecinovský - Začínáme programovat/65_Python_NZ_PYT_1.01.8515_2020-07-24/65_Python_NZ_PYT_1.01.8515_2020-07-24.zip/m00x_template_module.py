#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/m00x_module_template.py
"""
Dokumentační komentář modulu.
"""

# print(f'===== Modul {__name__} ===== START')


# print(f'===== Modul {__name__} ===== STOP')
