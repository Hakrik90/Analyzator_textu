#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/m00x_module_template.py
"""
Pomocný modul pro nastavování hladiny kontrolních tisků
a případné další služby spojené s laděním.
"""
DBG = 1      # Nastavení hladiny kontrolních tisků
from dbg import DBG
if DBG>0: print(f'===== Modul {__name__} ===== START')
############################################################################


############################################################################
if DBG>0: print(f'===== Modul {__name__} ===== STOP')
