#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/m15__take_put_actions.py
"""
Příkazy a záznamy odpovědí zadávané ve výpisech kapitoly:
15  Příkazy Vezmi a Polož
"""



#Výpis 15.1: Definice abstraktní třídy _AAction v modulu actions v balíčku game_v1e
############################################################################

# Definice je v souboru ./game/game_v1e/actions.py



#Výpis 15.2: Definice abstraktní třídy AItemContainer v modulu world v balíčku game_v1e
############################################################################

# Definice je v souboru ./game/game_v1e/world.py



#Výpis 15.3: Upravené definice initoru třídy ANamed v modulu world v balíčku game_v1e
############################################################################

# Definice je v souboru ./game/game_v1e/world.py



#Výpis 15.4: Upravené definice tříd Place a Bag v modulu world v balíčku game_v1e
############################################################################

# Definice je v souboru ./game/game_v1e/world.py



#Výpis 15.5: Definice třídy Take v modulu actions v balíčku game_v1e
############################################################################

# Definice je v souboru ./game/game_v1e/actions.py



#Výpis 15.6: Definice třídy _Put v modulu actions v balíčku game_v1e
############################################################################

# Definice je v souboru ./game/game_v1e/actions.py



#Výpis 15.7: Upravená definice metody initialize() v modulu world v balíčku game_v1e
############################################################################

# Definice je v souboru ./game/game_v1e/world.py



#Výpis 15.8: Konec zprávy o průběhu testu aplikace v balíčku game_v1e
############################################################################
# =============================== RESTART: Shell ==============================
import game.game_v1e.scenarios
# ##### game - Společný rodičovský balíček balíčků jednotlivých verzí her
# ##### game.game_v1e - Balíček s verzí hry na konci 15. kapitoly
#       po definici příkazů Vezmi a Polož
# ===== Modul game.game_v1e.scenarios ===== START
# ===== Modul game.game_v1e.world ===== START
# ===== Modul game.game_v1e.world ===== STOP
# ===== Modul game.game_v1e.game ===== START
# ===== Modul game.game_v1e.actions ===== START
# ===== Modul game.game_v1e.actions ===== STOP
# ===== Modul game.game_v1e.game ===== STOP
# ===== Modul game.game_v1e.scenarios ===== STOP
# Spuštěna metoda game.game_v1e.game.game_v1e.scenarios.test_scenario
# 0.
# ------------------------------
#
# ------------------------------
# Vítejte!
# Toto je příběh o Červené Karkulce, babičce a vlkovi.
# Svými příkazy řídíte Karkulku, aby donesla věci babičce.
# Nebudete-li si vědět rady, zadejte znak ?.
# ============================================================
#
# 1.
# ------------------------------
# Vezmi víno
# ------------------------------
# Karkulka dala do košíku objekt: Víno
# ============================================================
#
# 2.
# ------------------------------
# Vezmi bábovka
# ------------------------------
# Karkulka dala do košíku objekt: Bábovka
# ============================================================
#
# 3.
# ------------------------------
# Jdi LES
# ------------------------------
# Tento příkaz neznám: jdi
# ============================================================
#
# V 3. kroku neodpovídá: odpověď hry
#    Očekáváno: Karkulka se přesunula do prostoru:
# Les s jahodami, malinami a pramenem vody
#    Obdrženo:  Tento příkaz neznám: jdi
# Stisk klávesy Enter aplikaci ukončí
# >>>



############################################################################
##### KONEC #####
