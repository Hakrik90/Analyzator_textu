#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/m16_application_start.py
"""
Příkazy a záznamy odpovědí zadávané ve výpisech kapitoly:
16  Rozběhnutí aplikace
"""



#Výpis 16.1: Definice třídy _GoTo v modulu actions v balíčku game_v1f
############################################################################

# Definice je v souboru ./game/game_v1f/actions.py



#Výpis 16.2: Konec zprávy o průběhu testu
############################################################################



#Výpis 16.3: Definice metody __str__() ve třídě _Step v modulu world v balíčku game_v1f
############################################################################



#Výpis 16.4: Definice funkce simulate_with_state() v modulu actions v balíčku game_v1f
############################################################################

# Definice je v souboru ./game/game_v1f/actions.py



#Výpis 16.5: Definice funkce current_state() v modulu game v balíčku game_v1f
############################################################################

# Definice je v souboru ./game/game_v1f/game.py



#Výpis 16.6: Definice funkce _error() v modulu scenarios v balíčku game_v1f
############################################################################

# Definice je v souboru ./game/game_v1f/scenarios.py



#Výpis 16.7: Upravená definice části funkce test_scenario() v modulu scenarios v balíčku game_v1f
############################################################################

# Definice je v souboru ./game/game_v1f/scenarios.py



#Výpis 16.8: Konec zprávy o průběhu testu
############################################################################



#Výpis 16.9: Upravená definice funkce current_state() v modulu game v balíčku game_v1f
############################################################################

# Definice je v souboru ./game/game_v1f/game.py



#Výpis 16.10: Definice metody initialize()ve třídě Place v modulu world v balíčku game_v1f
############################################################################

# Definice je v souboru ./game/game_v1f/world.py



#Výpis 16.11: Definice třídy _End v modulu actions v balíčku game_v1f
############################################################################

# Definice je v souboru ./game/game_v1f/actions.py



############################################################################
##### KONEC #####
