#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/__init__Template.py
"""
Šablona pro initory podbalíčků - ty budou
v dokumentaci i v kontrolním tisku obsahovat text:
Balíček s verzí hry na konci X. kapitoly
po «stručná charakteristika posledního rozšíření»\
"""

print(f'''##### {__name__} - \
Balíček s verzí hry na konci X. kapitoly
     po «stručná charakteristika posledního rozšíření»\
''')
