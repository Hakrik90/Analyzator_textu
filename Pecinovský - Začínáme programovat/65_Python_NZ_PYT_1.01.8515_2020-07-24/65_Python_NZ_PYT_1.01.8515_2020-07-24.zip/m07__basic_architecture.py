#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/chapters/m07__basic_architecture.py
"""
Příkazy a záznamy odpovědí zadávané ve výpisech kapitoly:
7  Návrh základní architektury
"""



#Výpis 7.1: Definice modulu world
############################################################################

# Definice je v souboru ./game/game_v1a/world.py



#Výpis 7.2: Šablona initorů balíčků
############################################################################

# Definice je v souboru ./__init__.py



#Výpis 7.3: Definice modulu game.game_v1a.m07a_relative_import
############################################################################

# Definice je v souboru ./game/game_v1a/m07a_relative_import.py



#Výpis 7.4: Import modulu game.game_v1a.m07a_relative_import
############################################################################
import game.game_v1a.m07a_relative_import
# ##### game - Společný rodičovský balíček balíčků jednotlivých verzí her
# ##### game.game_v1a - Balíček s verzí hry na konci 7., resp. 9. kapitoly
#       po prvotní analýze (7. kapitola) a
#       po návrhu šťastného scénáře a simulačních metod (9. kapitola)
# ===== Modul game.game_v1a.m07a_relative_import ===== START
# ===== Modul game.game_v1a.game ===== START
# ===== Modul game.game_v1a.game ===== STOP
# ===== Modul game.m07b_imported ===== START
# ===== Modul game.m07b_imported ===== STOP
# ##### game.game_v1b - Balíček s verzí hry na konci 11. kapitoly
#       po definici testu hry
# ===== Modul game.game_v1b.m07c_imported ===== START
# ===== Modul game.game_v1b.m07c_imported ===== STOP
# ===== Modul game.game_v1a.m07a_relative_import ===== STOP
# >>>



############################################################################
##### KONEC #####
