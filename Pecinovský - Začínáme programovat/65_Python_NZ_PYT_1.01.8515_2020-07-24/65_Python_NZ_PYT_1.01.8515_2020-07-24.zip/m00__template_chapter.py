#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/m00__chapter_template.py
"""
Příkazy a záznamy odpovědí zadávané ve výpisech kapitoly:
X  NÁZEV_KAPITOLY.
"""



#Výpis 00.0: Popisek
############################################################################



############################################################################
##### KONEC #####
