#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/__init__.py
"""
Společný rodičovský balíček balíčků jednotlivých verzí her.
"""
from dbg import DBG
if DBG>0: print(f'''##### {__name__} - \
Společný rodičovský balíček balíčků jednotlivých verzí her\
''')
