#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v1a/actions.py
"""
Modul action má na starosti zpracování příkazů.
"""
print(f'===== Modul {__name__} ===== START')
############################################################################


############################################################################
print(f'===== Modul {__name__} ===== STOP')
