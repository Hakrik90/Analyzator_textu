#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v1a/__init__.py
"""
Balíček s verzí hry na konci 7. resp. 9. kapitoly
      po prvotní analýze zadaného problému (7) a 
      po návrhu šťastného scénáře a simulačních metod (9. kapitola).
"""

print(f'''##### {__name__} - \
Balíček s verzí hry na konci 7., resp. 9. kapitoly
      po prvotní analýze (7. kapitola) a
      po návrhu šťastného scénáře a simulačních metod (9. kapitola)\
''')
