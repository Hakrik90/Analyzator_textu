#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v1c/__init__.py
"""
Balíček s verzí hry na konci 12. kapitoly
po definici startu hry.
"""


print(f'''##### {__name__} - \
Balíček s verzí hry na konci 12. kapitoly
      po definici startu hry\
''')
