#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v1i/__init__.py
"""
Balíček s verzí hry na konci 19. kapitoly
po doplnění uživatelského rozhraní, omezení ladících tisků
a přípravy pro zpracování argumentů z příkazového řádku
po vytvoření aplikace jako samostatně spustitelného programu.
"""

from dbg import DBG
if DBG>0: print(f'''##### {__name__} - \
Balíček s verzí hry na konci 19. kapitoly
      po dodání uživatelského rozhraní, omezení ladících tisků
      a přípravy pro zpracování argumentů z příkazového řádku 
      po vytvoření aplikace jako samostatně spustitelného programu.\
''')
