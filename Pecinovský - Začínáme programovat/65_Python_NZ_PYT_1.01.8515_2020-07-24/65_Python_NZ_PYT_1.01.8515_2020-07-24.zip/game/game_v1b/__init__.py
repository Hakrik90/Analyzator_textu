#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v1b/__init__.py
"""
Balíček s verzí hry na konci 11. kapitoly
po definici testu hry.
"""


print(f'''##### {__name__} - \
Balíček s verzí hry na konci 11. kapitoly
      po definici testu hry\
''')
