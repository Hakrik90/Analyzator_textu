#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v1b/game.py
"""
Modul reprezentuje hru.
"""
print(f'===== Modul {__name__} ===== START')
############################################################################

# Příznak toho, zda hra právě běží (True), anebo jen čeká na další spuštění
is_active = False   # Na počátku čeká, až ji někdo spustí


def execute_command(command: str) -> str:
    """Zpracuje zadaný příkaz a vrátí string se zprávou pro uživatele."""
    return 'Prozatímní text'


############################################################################
print(f'===== Modul {__name__} ===== STOP')
