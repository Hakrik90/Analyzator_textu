#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v1d/__init__.py
"""
Balíček s verzí hry na konci 14. kapitoly 
po definici inicializace světa.
"""


print(f'''##### {__name__} - \
Balíček s verzí hry na konci 14. kapitoly
      po definici inicializace světa\
''')
