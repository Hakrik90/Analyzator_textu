#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v1f/__init__.py
"""
Balíček s verzí hry na konci 16. kapitoly
po úspěšném projití šťastným testem.
"""


print(f'''##### {__name__} - \
Balíček s verzí hry na konci 16. kapitoly
      po úspěšném projití šťastným testem\
''')
