#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v2b/__init__.py
"""
Balíček s verzí hry na konci 21. kapitoly
po definici superjednoduchého GUI.
"""
from dbg import DBG
if DBG>0: print(f'''##### {__name__} - \
Balíček s verzí hry na konci 21. kapitoly
      po definici superjednoduchého GUI\
''')
