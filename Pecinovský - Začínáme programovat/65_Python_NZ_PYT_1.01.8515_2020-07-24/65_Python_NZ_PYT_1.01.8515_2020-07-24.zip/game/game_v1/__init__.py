print('Načítá se modul balíčku', __name__)
