#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v1e/__init__.py
"""
Balíček s verzí hry na konci 15. kapitoly
po definici příkazů Vezmi a Polož.
"""


print(f'''##### {__name__} - \
Balíček s verzí hry na konci 15. kapitoly
      po definici příkazů Vezmi a Polož\
''')
