#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/game/game_v1h__init__.py
"""
Balíček s verzí hry na konci 18. kapitoly
po dotažení definice batohu a příkazu nápovědy a
po rozchození aplikace vyhovující všem napsaným testům.
"""


print(f'''##### {__name__} - \
Balíček s verzí hry na konci 18. kapitoly
      po dotažení batohu a nápovědy\
''')
