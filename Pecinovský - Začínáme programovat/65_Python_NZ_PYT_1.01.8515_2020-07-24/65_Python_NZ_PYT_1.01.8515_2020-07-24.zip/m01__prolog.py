#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/m01__prolog.py
"""
Příkazy a záznamy odpovědí zadávané ve výpisech kapitoly:
1  Předehra
"""



#Výpis 2.1: Zadání jednoduchého příkazu
############################################################################
123 + 456
# 579
#>>>



############################################################################
##### KONEC #####
