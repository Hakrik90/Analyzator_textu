#Příliš žluťoučký kůň úpěl ďábelské ó - PŘÍLIŠ ŽLUŤOUČKÝ KŮŇ ÚPĚL ĎÁBELSKÉ Ó
#Q:/65_PGM/65_PYT/m19a_script.py
"""
Modul pro demonstraci rozpoznání režimu, v němž je spouštěn.
"""
print(f'===== Modul {__name__} ===== START')

if __name__ == '__main__':
    print(f'Skript je spouštěn ze systému')
else:
    print(f'Skript je spouštěn v interaktivním režimu')

print(f'===== Modul {__name__} ===== STOP')
